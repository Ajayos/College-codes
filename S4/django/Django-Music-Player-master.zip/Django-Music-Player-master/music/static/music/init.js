$(document).ready(function(){
    $('.sidenav').sidenav();
    $('.collapsible').collapsible();
});